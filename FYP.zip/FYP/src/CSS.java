import com.steadystate.css.parser.CSSOMParser;
import org.w3c.dom.css.CSSStyleSheet;
import org.w3c.dom.css.CSSRuleList;
import org.w3c.css.sac.InputSource;
import org.w3c.dom.css.CSSRule;
import org.w3c.dom.css.CSSStyleRule;
import org.w3c.dom.css.CSSStyleDeclaration;
import java.io.*;
import java.util.Scanner;
 
 
public class CSS 
{
 
    protected static CSS oParser;
 
    public static void main(String[] args) throws IOException {
 
            oParser = new CSS();
 
            if (oParser.Parse("design.css")) {
 
                System.out.println("Parsing completed OK");
 
            } else {
 
                System.out.println("Unable to parse CSS");
 
            }
            
            editTextFile("log.txt");
            ReadFromFileUsingScanner("log6.txt");
            
    }
    
    
 
 
     public boolean Parse(String cssfile) 
     {
 
         FileOutputStream out = null; 
         PrintStream ps = null; 
         boolean rtn = false;

         try
         {
 
                // cssfile accessed as a resource, so must be in the pkg (in src dir).
                InputStream stream = oParser.getClass().getResourceAsStream(cssfile);
                 //InputStream stream = new FileInputStream(cssfile);
 
                 // overwrites and existing file contents
                 out = new FileOutputStream("log.txt");
 
                 if (out != null)
                 {
                     //log file
                     ps = new PrintStream( out );
                     System.setErr(ps); //redirects stderr to the log file as well
 
                 } else {
 
                     return rtn; 
 
                }
 
 
                InputSource source = new InputSource(new InputStreamReader(stream));
                CSSOMParser parser = new CSSOMParser();
                // parse and create a stylesheet composition
                CSSStyleSheet stylesheet = parser.parseStyleSheet(source, null, null);
 
                //ANY ERRORS IN THE DOM WILL BE SENT TO STDERR HERE!!
                // now iterate through the dom and inspect.
 
                CSSRuleList ruleList = stylesheet.getCssRules();
 
                ps.println("Number of rules: " + ruleList.getLength());
 
 
               for (int i = 0; i < ruleList.getLength(); i++) 
               {
                 CSSRule rule = ruleList.item(i);
                 if (rule instanceof CSSStyleRule) 
                 {
                     CSSStyleRule styleRule=(CSSStyleRule)rule;
                     ps.println("selector:" + i + ": " + styleRule.getSelectorText());
                     CSSStyleDeclaration styleDeclaration = styleRule.getStyle();
 
 
                     for (int j = 0; j < styleDeclaration.getLength(); j++)                        // loop
                     {
                          String property = styleDeclaration.item(j);
                          ps.println("property: " + property);
                          if (property.equals("background-color")) {
                        	  String originalValue = styleDeclaration.getPropertyCSSValue(property).getCssText();
                        	  //System.out.println("OV:"+originalValue);
                        	  String[] ovArray = originalValue.split(",", 5);
                        	  
                        	  String redValue = ovArray[0].replace("rgb(", "");
                        	  String redValue2 = redValue.replace("", "");
                        	  
                        	  String greenValue = ovArray[1].replace("", "");
                        	  String greenValue2 = greenValue.replace(" ", "");
                        	  
                        	  String blueValue = ovArray[2].replace(")", "");
                        	  String blueValue2 = blueValue.replace(" ", "");
                        	  
                        	  int blueLightChecking = Integer.parseInt(blueValue2);
                        	  int redBeforeReverse;
                        	  String redReverse = "";
                        	  int greenBeforeReverse;
                        	  String greenReverse = "";
                        	  int blueBeforeReverse;
                        	  String blueReverse = "";
                        	  
                        	  if (blueLightChecking > 150) {
                        		  
                        		  redBeforeReverse = Integer.parseInt(redValue2)/2;
                            	  redReverse = String.valueOf(redBeforeReverse);
                            	  greenBeforeReverse = Integer.parseInt(greenValue2);
                            	  greenReverse = String.valueOf(greenBeforeReverse);
                            	  blueBeforeReverse = Integer.parseInt(blueValue2)/3;
                            	  blueReverse = String.valueOf(blueBeforeReverse);
                        		  
                        	  } else if (blueLightChecking > 90){
                        		  
                        		  redBeforeReverse = Integer.parseInt(redValue2);
                            	  redReverse = String.valueOf(redBeforeReverse);
                            	  greenBeforeReverse = Integer.parseInt(greenValue2);
                            	  greenReverse = String.valueOf(greenBeforeReverse);
                            	  blueBeforeReverse = Integer.parseInt(blueValue2)/2;
                            	  blueReverse = String.valueOf(blueBeforeReverse);
                        		  
                        	  } else {
                        		  
                        		  redBeforeReverse = Integer.parseInt(redValue2);
                            	  redReverse = String.valueOf(redBeforeReverse);
                            	  greenBeforeReverse = Integer.parseInt(greenValue2);
                            	  greenReverse = String.valueOf(greenBeforeReverse);
                            	  blueBeforeReverse = Integer.parseInt(blueValue2);
                            	  blueReverse = String.valueOf(blueBeforeReverse);
                        		  
                        	  }
                        	  
                        	  String newValue = "rgb(" + redReverse + "," + greenReverse + ", " + blueReverse + ")";
                        	  
                        	  ps.println("value: " + newValue);
                          } else {
                        	  ps.println("value: " + styleDeclaration.getPropertyCSSValue(property).getCssText());
                          }
                          //ps.println("priority: " + styleDeclaration.getPropertyPriority(property));
                     }
 
 
 
                  }// end of StyleRule instance test
                 CSSStyleRule styleRule=(CSSStyleRule)rule;
                 if(styleRule.getSelectorText().equals("*.loginproductname")) //reads css names
                 {
                	 ps.println("selector:" + i + ": " + styleRule.getSelectorText());
                     CSSStyleDeclaration styleDeclaration = styleRule.getStyle();
                  for (int j = 0; j < styleDeclaration.getLength(); j++)  // loop
                   {
                	 System.out.println("Hi");
                     String property = styleDeclaration.item(j);
                     if(property.equals("color"))
                       {
                         styleDeclaration.getPropertyCSSValue(property).setCssText("yellow");
                       }
                    }
                 }
                } // end of ruleList loop
 
               if (out != null) out.close();
               if (stream != null) stream.close();
               rtn = true;
            }
            catch (IOException ioe)
            {
                System.err.println ("IO Error: " + ioe);
            }
            catch (Exception e)
            {
                System.err.println ("Error: " + e);
 
            }
            finally
            {
                if (ps != null) ps.close(); 
            }
 
            return rtn;
  
     }
     
	 
	 /*
	  remove everything before margin and add body {
	  * remove property: before all the property
	  * remove value before all the values
	  * join property and values together
	  * add } after 14px;
	  * add h1 { before font-size
	  * add } after 5px;
	  * *
	  */
     
     public static void editTextFile(String textFile) throws IOException {
    	 
    	 editTextFilePartOne(textFile);
    	 editTextFilePartTwo("log1.txt");
    	 editTextFilePartThree("log2.txt");
    	 editTextFilePartFour("log3.txt");
    	 editTextFilePartFive("log4.txt");
    	 editTextFilePartSix("log5.txt");
    	 
    	 
     }
     
     public static void editTextFilePartOne(String textFile) throws FileNotFoundException {
    	 
    	 
    	 BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));
    	 
    	 try {
    		 
    		 FileWriter writer = new FileWriter("log1.txt", false);
             BufferedWriter bufferedWriter = new BufferedWriter(writer);
    	     String line = bufferedReader.readLine();
    	     while(line != null) {
    	    	 bufferedWriter.write(line.replaceAll("property: ", ""));
    	    	 bufferedWriter.newLine();
    	         //System.out.println(line);
    	         line = bufferedReader.readLine();
    	     }
    	     
    	     bufferedReader.close();
    	     bufferedWriter.close();
    	 } catch (FileNotFoundException e) {
    	     // exception handling
    	 } catch (IOException e) {
    	     // exception handling
    	 }
    	 
        
     }
     
     public static void editTextFilePartTwo(String textFile) throws FileNotFoundException {
    	 
    	 
    	 BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));
    	 
    	 try {
    		 
    		 FileWriter writer = new FileWriter("log2.txt", false);
             BufferedWriter bufferedWriter = new BufferedWriter(writer);
    	     String line = bufferedReader.readLine();
    	     while(line != null) {
    	    	 bufferedWriter.write(line.replaceAll("value: ", ""));
    	    	 bufferedWriter.newLine();
    	         //System.out.println(line);
    	         line = bufferedReader.readLine();
    	     }
    	     
    	     bufferedReader.close();
    	     bufferedWriter.close();
    	 } catch (FileNotFoundException e) {
    	     // exception handling
    	 } catch (IOException e) {
    	     // exception handling
    	 }
    	 
        
     }
     
	public static void editTextFilePartThree(String textFile) throws IOException {
	    	 
	    	 
		File inputFile = new File("log2.txt");
		File tempFile = new File("log3.txt");
	
		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
	
		String lineToRemove = "Number of rules: 2";
	    String lineToRemove2 = "selector:0: body";
	    String lineToRemove3 = "selector:1: h1";
		String currentLine;
	
		while((currentLine = reader.readLine()) != null) {
		    // trim newline when comparing with lineToRemove
		    String trimmedLine = currentLine.trim();
		    if(trimmedLine.equals(lineToRemove) || trimmedLine.equals(lineToRemove2) || trimmedLine.equals(lineToRemove3)) continue;
		    writer.write(currentLine + System.getProperty("line.separator"));
		}
		writer.close(); 
		reader.close(); 
	    	 
	        
	  }
	
	public static void editTextFilePartFour(String textFile) throws FileNotFoundException {
   	 
   	 
   	 BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));
   	 
   	 try {
   		 
   		 FileWriter writer = new FileWriter("log4.txt", false);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
   	     String line = bufferedReader.readLine();
   	     while(line != null) {
   	    	 bufferedWriter.write(line.replaceAll(" ", ""));
   	    	 bufferedWriter.newLine();
   	         //System.out.println(line);
   	         line = bufferedReader.readLine();
   	     }
   	     
   	     bufferedReader.close();
   	     bufferedWriter.close();
   	 } catch (FileNotFoundException e) {
   	     // exception handling
   	 } catch (IOException e) {
   	     // exception handling
   	 }
   	 
       
    }

	
	public static void editTextFilePartFive(String textFile) throws IOException {
		
		
        StringBuilder output = new StringBuilder();
        try (Scanner sc1 = new Scanner((new File(textFile)))) {
        	boolean oddrows = true;
        	String s1 = null;
        	String s2 = null;

            while (sc1.hasNext()) {
            	if (oddrows == true) {
            		s1 = (sc1.hasNext() ? sc1.next() : "");
            		oddrows = false;
            	} 
            	if (oddrows == false){
            		s2 = (sc1.hasNext() ? sc1.next() : "");
            		oddrows = true;
            	}                
                
                output.append("  ").append(s1).append(": ").append(s2).append(";");
                output.append("\n");
            }
        }
        try (PrintWriter pw = new PrintWriter(new File("log5.txt"))) {
            pw.write(output.toString());
        }
        
        
        
        
    }
	
	@SuppressWarnings("unlikely-arg-type")
	public static void editTextFilePartSix(String textFile) throws IOException {
		
		
		BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));
		String lineToAdd = "body { ";
	    String lineToAdd2 = "}" + "\n" + "h1 {" + "\n";
	    String lineToAdd3 = "\n" + "}";
		
		try {
   		 
   		 FileWriter writer = new FileWriter("log6.txt", false);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
   	     String line = bufferedReader.readLine();
   	     int counter = 0;
   	     
   	     while(line != null) {
   	    	 
   	    	if (counter == 0) {
   	    		 line = lineToAdd + "\n" + line;
   	    	}
   	    	if (counter == 4) {
  	    		 line = lineToAdd2 + line;
  	    	}
   	    	if (counter == 6) {
  	    		 line = line + lineToAdd3;
  	    	 }
   	    	counter++;
   	    	bufferedWriter.write(line);
   	    	bufferedWriter.newLine();
   	        //System.out.println(line);
   	        line = bufferedReader.readLine();
   	     }
   	     
   	     bufferedReader.close();
   	     bufferedWriter.close();
   	 } catch (FileNotFoundException e) {
   	     // exception handling
   	 } catch (IOException e) {
   	     // exception handling
   	 }
		
		
		
	}
	
	
	
	
     
     public static void ReadFromFileUsingScanner(String textFile) throws FileNotFoundException
     { 
    	 
         try (
        		 
        		    FileReader reader = new FileReader(textFile);
        		    FileWriter writer = new FileWriter("EditedDesign.css");
        		) {
        		 
        		    int charRead = -1;
        		 
        		    while ((charRead = reader.read()) != -1) {
        		        writer.write(charRead);
        		    }
        		 
        		} catch (IOException ex) {
        		    System.err.println(ex);
        		}
         
     } 
     
     
     
     
     
}